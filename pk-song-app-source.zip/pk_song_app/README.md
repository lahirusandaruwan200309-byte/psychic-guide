# pk-song

A simple Flutter starter app for Android + iPhone with a black/white look.

## What it does
- No login required
- Searchable song list
- Favorites
- Opens official YouTube links for playback

## Run it
```bash
flutter pub get
flutter run
```

## Build Android
```bash
flutter build apk
```

## Build iPhone
Use macOS + Xcode:
```bash
flutter build ios
```

## Notes
This is a clean starter project. If you want in-app YouTube playback or social login, add the relevant Flutter packages and API keys.

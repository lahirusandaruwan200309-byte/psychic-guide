import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const PKSongApp());
}

class PKSongApp extends StatelessWidget {
  const PKSongApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'pk-song',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0B0B0B),
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.white,
          brightness: Brightness.dark,
          primary: Colors.white,
          surface: const Color(0xFF141414),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0B0B0B),
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF171717),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide.none,
          ),
        ),
        cardTheme: CardTheme(
          color: const Color(0xFF141414),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        ),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class Song {
  final String title;
  final String artist;
  final String youtubeUrl;
  final String mood;

  const Song({
    required this.title,
    required this.artist,
    required this.youtubeUrl,
    required this.mood,
  });
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _search = TextEditingController();
  final Set<String> _favorites = {};
  String _query = '';
  Song? _nowPlaying;

  final List<Song> _songs = const [
    Song(
      title: 'Kesariya',
      artist: 'Arijit Singh',
      youtubeUrl: 'https://www.youtube.com/watch?v=BddP6PYo2gs',
      mood: 'Trending',
    ),
    Song(
      title: 'Pasoori',
      artist: 'Ali Sethi, Shae Gill',
      youtubeUrl: 'https://www.youtube.com/watch?v=5Eqb_-j3FDA',
      mood: 'Trending',
    ),
    Song(
      title: 'Perfect',
      artist: 'Ed Sheeran',
      youtubeUrl: 'https://www.youtube.com/watch?v=2Vv-BfVoq4g',
      mood: 'Love',
    ),
    Song(
      title: 'Shape of You',
      artist: 'Ed Sheeran',
      youtubeUrl: 'https://www.youtube.com/watch?v=JGwWNGJdvx8',
      mood: 'Pop',
    ),
    Song(
      title: 'Levitating',
      artist: 'Dua Lipa',
      youtubeUrl: 'https://www.youtube.com/watch?v=TUVcZfQe-Kw',
      mood: 'Party',
    ),
    Song(
      title: 'Blinding Lights',
      artist: 'The Weeknd',
      youtubeUrl: 'https://www.youtube.com/watch?v=4NRXx6U8ABQ',
      mood: 'Pop',
    ),
    Song(
      title: 'Shallow',
      artist: 'Lady Gaga, Bradley Cooper',
      youtubeUrl: 'https://www.youtube.com/watch?v=bo_efYhYU2A',
      mood: 'Movie',
    ),
    Song(
      title: 'Senorita',
      artist: 'Shawn Mendes, Camila Cabello',
      youtubeUrl: 'https://www.youtube.com/watch?v=Pkh8UtuejGw',
      mood: 'Romantic',
    ),
  ];

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<Song> get _filteredSongs {
    final q = _query.trim().toLowerCase();
    if (q.isEmpty) return _songs;
    return _songs.where((s) {
      return s.title.toLowerCase().contains(q) ||
          s.artist.toLowerCase().contains(q) ||
          s.mood.toLowerCase().contains(q);
    }).toList();
  }

  Future<void> _openSong(Song song) async {
    setState(() => _nowPlaying = song);
    final uri = Uri.parse(song.youtubeUrl);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('YouTube open කරන්න බැරි වුණා.')),
      );
    }
  }

  void _toggleFavorite(Song song) {
    setState(() {
      if (_favorites.contains(song.youtubeUrl)) {
        _favorites.remove(song.youtubeUrl);
      } else {
        _favorites.add(song.youtubeUrl);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final favorites = _songs.where((s) => _favorites.contains(s.youtubeUrl)).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'pk-song',
          style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 0.5),
        ),
        actions: [
          IconButton(
            onPressed: () => setState(() => _query = ''),
            icon: const Icon(Icons.refresh_rounded),
            tooltip: 'Reset',
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _Header(nowPlaying: _nowPlaying),
            const SizedBox(height: 16),
            TextField(
              controller: _search,
              onChanged: (v) => setState(() => _query = v),
              decoration: const InputDecoration(
                hintText: 'Search songs, artists, moods...',
                prefixIcon: Icon(Icons.search_rounded),
              ),
            ),
            const SizedBox(height: 16),
            _SectionTitle(
              title: 'Songs',
              subtitle: '${_filteredSongs.length} found',
            ),
            const SizedBox(height: 8),
            ..._filteredSongs.map(
              (song) => _SongTile(
                song: song,
                isFavorite: _favorites.contains(song.youtubeUrl),
                onTap: () => _openSong(song),
                onFavoriteTap: () => _toggleFavorite(song),
              ),
            ),
            const SizedBox(height: 12),
            if (favorites.isNotEmpty) ...[
              const _SectionTitle(title: 'Favorites', subtitle: 'Saved tracks'),
              const SizedBox(height: 8),
              ...favorites.map(
                (song) => _SongTile(
                  song: song,
                  isFavorite: true,
                  onTap: () => _openSong(song),
                  onFavoriteTap: () => _toggleFavorite(song),
                ),
              ),
            ],
            const SizedBox(height: 18),
            const _SectionTitle(title: 'About', subtitle: 'No login required'),
            const SizedBox(height: 8),
            const _InfoCard(
              text:
                  'This starter app is built for Android and iPhone with a black/white look. It opens official YouTube links only, so it stays simple and safe.',
            ),
          ],
        ),
      ),
      bottomNavigationBar: _BottomNowPlaying(
        nowPlaying: _nowPlaying,
        onPlay: _nowPlaying == null ? null : () => _openSong(_nowPlaying!),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final Song? nowPlaying;
  const _Header({required this.nowPlaying});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            Container(
              height: 64,
              width: 64,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: const LinearGradient(
                  colors: [Colors.white, Color(0xFF8A8A8A)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: const Icon(Icons.music_note_rounded, color: Colors.black, size: 32),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Listen to YouTube songs'),
                  const SizedBox(height: 4),
                  Text(
                    nowPlaying == null
                        ? 'Tap a song to start'
                        : 'Now playing: ${nowPlaying!.title}',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w700,
                        ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final String subtitle;
  const _SectionTitle({required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
        Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }
}

class _SongTile extends StatelessWidget {
  final Song song;
  final bool isFavorite;
  final VoidCallback onTap;
  final VoidCallback onFavoriteTap;

  const _SongTile({
    required this.song,
    required this.isFavorite,
    required this.onTap,
    required this.onFavoriteTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                height: 54,
                width: 54,
                decoration: BoxDecoration(
                  color: const Color(0xFF202020),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Icon(Icons.play_arrow_rounded, color: Colors.white),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(song.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 4),
                    Text('${song.artist} • ${song.mood}', style: Theme.of(context).textTheme.bodyMedium),
                  ],
                ),
              ),
              IconButton(
                onPressed: onFavoriteTap,
                icon: Icon(isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String text;
  const _InfoCard({required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Text(text, style: Theme.of(context).textTheme.bodyMedium),
      ),
    );
  }
}

class _BottomNowPlaying extends StatelessWidget {
  final Song? nowPlaying;
  final VoidCallback? onPlay;

  const _BottomNowPlaying({required this.nowPlaying, required this.onPlay});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF101010),
        border: Border(top: BorderSide(color: Color(0xFF222222))),
      ),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
      child: Row(
        children: [
          const Icon(Icons.headphones_rounded),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              nowPlaying == null
                  ? 'Nothing playing'
                  : 'Ready: ${nowPlaying!.title}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          FilledButton(
            onPressed: onPlay,
            child: const Text('Play'),
          ),
        ],
      ),
    );
  }
}
